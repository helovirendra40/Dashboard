import menuToggle from './Icons.png'
import user from './user.png'
import graph from './graph.png'
import hand_icon from './hand_icon.png'
import material_icon from './material_icon.png'
import star from './star.png'
import user_icon from './user_icon.png'
import cart from './cart.png'
import green_line_graph from './green-line-graph.png'
import red_line_graph from './red-line-graph.png'
import yellow_line_graph from './yellow-line-graph.png'
import service1 from './service1.png'
import service2 from './service2.png'
import service3 from './service3.png'
import service4 from './service4.png'
import user_icon1 from './user_Icon1.png'
import user_icon2 from './user_Icon2.png'
import user_icon3 from './user_Icon3.png'
import blankStar from './blankStar.png'

export const assets = {
  menuToggle,
  user,
  cart,
  user_icon,
  material_icon,
  hand_icon, star, graph,
  green_line_graph,
  red_line_graph,
  yellow_line_graph,
  service1,
  service2,
  service3,
  service4,
  user_icon1,
  user_icon2,
  user_icon3,
  blankStar,
}