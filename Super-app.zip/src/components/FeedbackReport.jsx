import React from 'react'

const FeedbackReport = () => {
  return (
    <>
    
     <div className='row'>
        <div className='col-md-5'>

        </div>
        <div className='col-md-7'>
            
        </div>
        </div> 
    </>
  )
}

export default FeedbackReport
